#ifndef SERVER_H
#define SERVER_H
#include "lookup_table.h"
#define MAX_DATA_SIZE 100 // max number of bytes we can get at once 
#define USER_NAME_LEN 20   //max length of USER NAME
#define DEFAULT_PORT "9034"   // port we're listening on

#endif //server.h